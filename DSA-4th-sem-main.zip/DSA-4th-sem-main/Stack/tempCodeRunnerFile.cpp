s->arr[0]=7;
    // s->top = 5;